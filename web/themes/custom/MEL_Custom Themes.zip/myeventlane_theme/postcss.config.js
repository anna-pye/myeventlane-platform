// PostCSS configuration for Vite
// Provides autoprefixer for automatic vendor prefixing
// This is optional - Vite works fine without it

export default {
  plugins: {
    autoprefixer: {},
  },
};


