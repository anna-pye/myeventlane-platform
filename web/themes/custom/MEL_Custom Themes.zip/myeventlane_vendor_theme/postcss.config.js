export default {
  plugins: {
    autoprefixer: {},
  },
};


















